from django.apps import AppConfig


class PollingwebsiteConfig(AppConfig):
    name = 'pollingwebsite'
